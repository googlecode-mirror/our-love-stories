<div id="footer">
<p>
 <a href="<?php bloginfo('rss2_url'); ?>">Entries (RSS)</a> and <a href="<?php bloginfo('comments_rss2_url'); ?>">Comments (RSS)</a>
</p>
<p>
 <?php bloginfo('name'); ?> is proudly powered by <a href="http://wordpress.org/">WordPress</a> and Love!
</p>
<p>
<a href="http://our-love-stories.com">Our Love Stories Theme</a> is designed by <a href="http://www.doublethinklog.com/"><strong>MC Geek</strong></a>.
</p>

<?php wp_footer(); ?>
</div>
</div>
</body></html>